@extends('layouts.appbo')

@section('content')
    <h1>CREATE</h1>

@endsection
