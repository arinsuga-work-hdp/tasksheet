<h5>Filter Data</h5>
<hr class="mb-2">
<form role="form">
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
                <input type="text" id="filter0" name="filter0" class="form-control float-right" placeholder="Name">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter1" name="filter1" class="form-control float-right" placeholder="Email" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter2" name="filter2" class="form-control float-right" placeholder="Status" style="margin-left: 5px;">
            </div>
        </div>
    </div>
</form>
