<div class="listrow listrow-between">
    <div class="listrow-item">
        @include('website.components.logo-shopee')
    </div>
    <div class="listrow-item">
        @include('website.components.logo-tokopedia')
    </div>
</div>

<div class="listrow pt-5">
    <div class="listrow-item">
        @include('website.components.logo-bukalapak')
    </div>
</div>