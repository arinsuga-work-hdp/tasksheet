<?php

return [
    'product' => 'product',
    'type1' => 'ALAT PERTANIAN',
    'type2' => 'PERLINDUNGAN TANAMAN',
    'type3' => 'PUPUK',
    'type4' => 'DRONE PERTANIAN',
];
