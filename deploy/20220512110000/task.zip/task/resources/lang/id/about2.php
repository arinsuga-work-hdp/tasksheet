<?php

return [
    'title' => 'LAYANAN KAMI',
    'desc1' => 'Teknologi drone Malindo di sektor pertanian sudah berjalan beberapa tahun terakhir. Ini telah dikembangkan oleh PT. Malindo Agrotek Perkasa untuk mencapai visi dan misi kami',
    'desc2' => 'Dengan teknologi drone, penyemprotan dapat dilakukan dengan cepat, menggunakan lebih sedikit air, meminimalkan paparan pestisida kepada petani, mampu menyemprot pada lahan yang sulit ditempuh',
    'desc3' => 'Drone meningkatkan efisiensi dan produktivitas pertanian di Indonesia',
    'flyer' => 'DRONE FLYER',
    'apps' => 'CONTACT US VIA APPS',

];
