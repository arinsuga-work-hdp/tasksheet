<?php

return [
    'hq' => 'KANTOR PUSAT',
    'branch' => 'KANTOR PERWAKILAN',
    'partner' => 'SUCCESS PARTNER IN AGRICULTURE SOLUTION',

];
