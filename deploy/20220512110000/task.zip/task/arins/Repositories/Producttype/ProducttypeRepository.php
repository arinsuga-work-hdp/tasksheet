<?php

namespace Arins\Repositories\Producttype;

use Arins\Repositories\BaseRepository;
use Arins\Repositories\Producttype\ProducttypeInterface;

class ProducttypeRepository extends BaseRepository implements ProducttypeRepositoryInterface
{
}