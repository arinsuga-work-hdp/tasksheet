<table id="filter" style="width: 100%;" class="table table-hover-pointer table-head-fixed text-nowrap">
    <thead>
        <tr>
            <th style="width: 5%;"></th>
            <th style="width: 15%;">NIK</th>
            <th style="width: 10%;">Nama</th>
            <th style="width: 50%;">Jabatan</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $viewModel->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onclick="window.location.assign('<?php echo e(route('employee.show', ['employee' => $item->id])); ?>');">
                <td>
                    <div class="image-table-cell">
                        <img src="<?php echo e(Arins\Facades\Filex::image($item->image)); ?>" alt="<?php echo e($item->name); ?>">
                    </div>
                </td>
                <td><?php echo e($item->nik); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/employee/data-list-items.blade.php ENDPATH**/ ?>