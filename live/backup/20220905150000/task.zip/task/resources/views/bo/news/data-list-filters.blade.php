<h5>Filter Data</h5>
<hr class="mb-2">
<form role="form">
    <input type="hidden" id="filter0" name="filter0">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
                <input type="text" id="filter1" name="filter1" class="form-control float-right" placeholder="Tanggal">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter2" name="filter2" class="form-control float-right" placeholder="Judul" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter3" name="filter3" class="form-control float-right" placeholder="Deskripsi" style="margin-left: 5px;">
            </div>
        </div>
    </div>
</form>
