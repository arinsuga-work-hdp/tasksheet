<?php (($fieldEnabled == true ? $disabled='' : $disabled='disabled')); ?>
<div class="card" style="margin-bottom: 20px; width: 50%;
margin-left: auto; margin-right:auto;">
    <div class="card-body">


<!-- Start Date -->
<div class="form-group">
  <label>Start Date Period:</label>

    <div class="row">

	<div class="input-group col-sm-12 col-md-6">
		<input type="text" class="form-control date" name="startdt" id="startdt"/>
		<div class="input-group-append">
			<div class="input-group-text"><i class="fa fa-calendar"></i></div>
		</div>
	</div>

	<div class="input-group col-sm-12 col-md-6">
		<input type="text" class="form-control date" name="enddt" id="enddt"/>
		<div class="input-group-append" >
			<div class="input-group-text"><i class="fa fa-calendar"></i></div>
		</div>
	</div>

    </div>

</div>


<div class="form-group">
    <label>Status</label>
    <select name="activitystatus_id" class="form-control select2">
        <option selected value="">All</option>
        <?php ($selected = ''); ?>
        <?php $__currentLoopData = $activitystatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php if($errors->any()): ?>
                <?php echo e(($item->id == old('activitystatus_id') ? $selected = 'selected' : $selected = '')); ?>

            <?php endif; ?>
            <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
        
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <p class="text-red"><?php echo e($errors->first('activitystatus_id')); ?></p>

</div>


        <div class="form-group">
            <label>Requester</label>
            <select name="enduser_id" class="form-control select2">
                <option selected value="">All</option>
                <?php ($selected = ''); ?>
                <?php $__currentLoopData = $enduser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($errors->any()): ?>
                    <?php echo e(($item->id == old('enduser_id') ? $selected = 'selected' : $selected = '')); ?>

                <?php endif; ?>
                <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-red"><?php echo e($errors->first('enduser_id')); ?></p>

        </div>

        <div class="form-group">
            <label>Teknisi</label>
            <select name="technician_id" class="form-control select2">
                <option selected value="">All</option>
                <?php ($selected = ''); ?>
                <?php $__currentLoopData = $technician; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($errors->any()): ?>
                        <?php echo e(($item->id == old('technician_id') ? $selected = 'selected' : $selected = '')); ?>

                    <?php endif; ?>
                    <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-red"><?php echo e($errors->first('technician_id')); ?></p>

        </div>

        <div class="form-group">
            <label>Jenis Pengaduan</label>
            <select name="activitysubtype_id" class="form-control select2">
                <option selected value="">All</option>
                <?php ($selected = ''); ?>
                <?php $__currentLoopData = $activitysubtype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($errors->any()): ?>
                        <?php echo e(($item->id == old('activitysubtype_id') ? $selected = 'selected' : $selected = '')); ?>

                    <?php endif; ?>
                    <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-red"><?php echo e($errors->first('activitysubtype_id')); ?></p>
        </div>

        <div class="form-group">
            <label>Kategori</label>
            <select id="tasktype_id" name="tasktype_id" class="form-control select2">
                <option selected value="">All</option>
                <?php ($selected = ''); ?>
                <?php $__currentLoopData = $tasktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($errors->any()): ?>
                        <?php echo e(($item->id == old('tasktype_id') ? $selected = 'selected' : $selected = '')); ?>

                    <?php endif; ?>
                    <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <p class="text-red"><?php echo e($errors->first('tasktype_id')); ?></p>

        </div>

        <div class="form-group">
            <label>Sub Kategori</label>
            <select id="tasksubtype1_id" name="tasksubtype1_id" class="form-control select2">
            </select>
            <p class="text-red"><?php echo e($errors->first('tasksubtype1_id')); ?></p>
        </div>

        <div class="form-group">
            <label>item</label>
            <select id="tasksubtype2_id" name="tasksubtype2_id" class="form-control select2">
            </select>
            <p class="text-red"><?php echo e($errors->first('tasksubtype2_id')); ?></p>

        </div>

    </div>
</div>


<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/support/index-custom-fields.blade.php ENDPATH**/ ?>