<a href="{{ config('a1.onlineshop.bukalapak.link') }}" target="_blank">
    <img class="logo-brand" src="{{ asset( config('a1.onlineshop.bukalapak.logo') ) }}" alt="">
</a>
