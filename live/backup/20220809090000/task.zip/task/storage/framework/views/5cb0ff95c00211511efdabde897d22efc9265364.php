<table id="filter" style="width: 100%;" class="table table-head-fixed text-nowrap">
    <thead>
        <tr>
            <th>Jenis Project</th>
            <th>Project</th>
            <th>Subject</th>
            <th>Description</th>
            <th>Resolution</th>
            <th>Created By</th>
            <th>Start Time</th>
            <th>Completed Time</th>
            <th>Time Elapsed</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $viewModel->data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->tasktype['name']); ?></td>
                <td><?php echo e($item->tasksubtype1['name']); ?></td>
                <td><?php echo e($item->subject); ?></td>
                <td><?php echo e($item->description); ?></td>
                <td><?php echo e($item->resolution); ?></td>
                <td><?php echo e($item->createdBy['name']); ?></td>
                <td><?php echo e(\Arins\Facades\Formater::datetime($item->startdt)); ?></td>
                <td><?php echo e(\Arins\Facades\Formater::datetime($item->enddt)); ?></td>
                <td><?php echo e($item->startdt->diffInHours($item->enddt)); ?>:<?php echo e($item->startdt->diff($item->enddt)->format('%I:%S')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/project/report-detail-list-items.blade.php ENDPATH**/ ?>