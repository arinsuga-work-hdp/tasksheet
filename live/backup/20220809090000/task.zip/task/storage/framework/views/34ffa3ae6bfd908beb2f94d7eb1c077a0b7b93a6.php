

<?php $__env->startSection('content_title', 'Report Detail'); ?>

<?php $__env->startSection('toolbar'); ?>

<li class="nav-item">
    <a class="nav-link" data-widget="control-sidebar" href="#" >
        <i class="fas fa-lg fa-filter"></i>
    </a>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('control_sidebar'); ?>
    <div class="control-sidebar-content">
        <?php echo $__env->make('bo.maintenance.report-detail-list-filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <nav class="navbar navbar-expand ">

            <ul class="navbar-nav">

                <li class="nav-item" style="border-bottom: 5px solid red;">
                    <a class="nav-link" href="<?php echo e(route('maintenance.report.detail')); ?>" style="font-weight: bold;">
                        All
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('maintenance.report.detail.custom')); ?>" style="font-weight: bold;">
                        Custom
                    </a>
                </li>

            </ul>

        </nav>

        <div style="margin-top: 10px;">
            <?php echo $__env->make('bo.maintenance.report-detail-list-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('js/CustomForIndex.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/maintenance/report-detail.blade.php ENDPATH**/ ?>