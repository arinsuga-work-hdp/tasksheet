<h5>Filter Data</h5>
<hr class="mb-2">
<form role="form">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter0" name="filter0" class="form-control float-right" placeholder="Jenis Project" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter1" name="filter1" class="form-control float-right" placeholder="Project" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter2" name="filter2" class="form-control float-right" placeholder="Subject" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter3" name="filter3" class="form-control float-right" placeholder="Description" style="margin-left: 5px;">
            </div>
        </div>
    </div>

    <input type="hidden" id="filter4" name="4">
    <input type="hidden" id="filter5" name="5">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter6" name="filter6" class="form-control float-right" placeholder="Start Time" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter7" name="filter7" class="form-control float-right" placeholder="Completed Time" style="margin-left: 5px;">
            </div>
        </div>
    </div>
</form>
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/project/report-detail-list-filters.blade.php ENDPATH**/ ?>