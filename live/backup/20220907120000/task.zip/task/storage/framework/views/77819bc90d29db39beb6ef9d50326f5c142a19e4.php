

<?php $__env->startSection('content_title', 'Maintenance List'); ?>

<?php $__env->startSection('toolbar'); ?>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.create')); ?>">
        <i class="fas fa-lg fa-plus"></i>
    </a>
</li>

<li class="nav-item">
    <a onclick="event.preventDefault(); document.getElementById('frmData').submit();"
       class="nav-link" href="#">
        <i class="fas fa-lg fa-search"></i>
    </a>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('control_sidebar'); ?>
    <div class="control-sidebar-content">
        <?php echo $__env->make('bo.maintenance.data-list-filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <nav class="navbar navbar-expand ">

            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('maintenance.index.today')); ?>" style="font-weight: bold;">
                        Today
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('maintenance.index.open')); ?>" style="font-weight: bold;">
                        Open
                    </a>
                </li>

                <li class="nav-item" style="border-bottom: 5px solid red;">
                    <a class="nav-link" href="<?php echo e(route('maintenance.index.custom')); ?>" style="font-weight: bold;">
                        Custom
                    </a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('maintenance.index')); ?>" style="font-weight: bold;">
                        All
                    </a>
                </li>

            </ul>

        </nav>

        <?php if(!isset($viewModel->data->datalist)): ?>
        <!-- Form Custom Search -->
        <div>

            <form role="form" id="frmData" method="POST" action="<?php echo e(route('maintenance.index.custom.post')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div style="display: flex; justify-content=center;">
                    <?php echo $__env->make('bo.maintenance.index-custom-fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </form>

        </div>        
        <?php endif; ?>

        <?php if(isset($viewModel->data->datalist)): ?>
            <div style="margin-top: 10px;">
                <?php echo $__env->make('bo.maintenance.index-custom-datalist', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('js/CustomForIndex.js')); ?>" defer></script>
    <?php echo $__env->make('bo.maintenance._script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/maintenance/index-custom.blade.php ENDPATH**/ ?>