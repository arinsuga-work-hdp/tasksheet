<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('img/'.config('a1.uiux.favicon'))); ?>"/>

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

  <title><?php echo e(config('a1.company.name', 'Demo')); ?></title>

    <!-- Styles -->
    <link href="<?php echo e(asset('css/admin.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('lib/flatpickr/flatpickr.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('plugins/select2/select2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/main.css')); ?>" rel="stylesheet">
    

    <?php echo $__env->yieldContent('style'); ?>

</head>
<body class="hold-transition sidebar-mini layout-fixed">

<div class="wrapper">

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-static navbar-static-top navbar-warning navbar-light">

    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fas fa-lg fa-bars"></i></a>
      </li>
    </ul>

    <ul class="navbar-nav">
      <li class="nav-item">
        <span class="navbar-link"><?php echo $__env->yieldContent('content_title'); ?></span>
      </li>
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">

      <?php echo $__env->yieldContent('toolbar'); ?>

    </ul>

  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(route('home.index')); ?>" class="brand-link">
      <img id="logoFull" src="<?php echo e(asset('img/'.config('a1.uiux.logo_landscape'))); ?>" alt="<?php echo e(config('a1.company.name','Demo')); ?>" class="brand-image elevation-3 logo-full">
      <img id="logoIcon" src="<?php echo e(asset('img/'.config('a1.uiux.logo_icon'))); ?>" alt="<?php echo e(config('a1.company.name','Demo')); ?>" class="brand-image elevation-3 logo-icon">
      <span class="brand-text font-weight-light"></span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?php echo e(asset('img/user2-160x160.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">


          <?php if(Auth::check()): ?>
          <a href="<?php echo e(route('home.index')); ?>" class="d-block"><?php echo e(Auth::user()->name); ?></a>
          <?php endif; ?>
          
        </div>
      </div>

      <!-- Sidebar Menu -->
      <?php echo $__env->make('layouts.appbo-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper" style="background-color: white;">

    <!-- Content Header (Page header) -->
    <div class="content-header" style="padding-top: 60px;">
      <div class="container-fluid">
        <!-- row mb-2 -->
        <div class="crud-container">

          <div class="crud-title">
            <h1 class="m-0 text-dark"></h1>
          </div><!-- /.col -->

          <div class="crud-toolbar crud-toolbar-end">
          </div>

        </div><!-- /.row -->

      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
          <?php echo $__env->yieldContent('content'); ?>
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Copyright &copy; <?php echo e(config('a1.company.copyright', '2020')); ?> <a href="<?php echo e(config('a1.company.website', route('home.index'))); ?>"><?php echo e(config('a1.company.name', 'Demo')); ?></a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> <?php echo e(config('a1.company.version','1.0')); ?>

    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="p-3 control-sidebar control-sidebar-dark" style="opacity: 90%;">
    <!-- Control sidebar content goes here -->
    <?php echo $__env->yieldContent('control_sidebar'); ?>
  </aside>
  <!-- /.control-sidebar -->
</div>


    <!-- Scripts -->
    <script src="<?php echo e(asset('js/manifest.js')); ?>"></script>
    <script src="<?php echo e(asset('js/vendor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/flatpickr/flatpickr.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/flatpickr/lang/id.js')); ?>"></script>
    <script src="<?php echo e(asset('lib/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/select2/select2.min.js')); ?>" defer></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
        
    <script src="<?php echo e(asset('js/main.js')); ?>" defer></script>
    <?php echo $__env->yieldContent('js'); ?>

</body>
</html>
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/layouts/appbo.blade.php ENDPATH**/ ?>