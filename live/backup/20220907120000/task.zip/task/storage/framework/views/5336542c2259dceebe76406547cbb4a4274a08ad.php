<script>
    flatpickr(".date", {
        enableTime: true,
        dateFormat: "<?php echo e(config('a1.datejs.datetime')); ?>"
    });
    
    //CKEDITOR.replace( 'description' );

</script>

<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/masterproject/_script.blade.php ENDPATH**/ ?>