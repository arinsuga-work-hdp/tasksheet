<?php (($fieldEnabled == true ? $disabled='' : $disabled='disabled')); ?>
<div class="card" style="margin-bottom: 20px; width: 50%;
margin-left: auto; margin-right:auto;">
    <div class="card-body">

      <!-- text input:file -->
      <div class="form-group">
        <input type="hidden" id="image" name="image" value="<?php echo e($viewModel->data->image); ?>">
        <input type="hidden" id="toggleRemoveImage" name="toggleRemoveImage" value="false">
        <input type="hidden" id="imageTemp" name="imageTemp" value="<?php echo e(session('imageTemp')); ?>">

        <?php if($fieldEnabled == true): ?>
          <label>Image</label>
          <div class="box full-width-sm">
              <?php if(session('imageTemp')): ?>
                <img id="imageViewer" src="<?php echo e(Arins\Facades\Filex::image(session('imageTemp'))); ?>" alt="">
              <?php else: ?>
                <img id="imageViewer" src="<?php echo e(Arins\Facades\Filex::image($viewModel->data->image)); ?>" alt="">
              <?php endif; ?>

              <?php if($viewModel->data->image): ?>
                <span class="control control-widebox">  
                  <a onclick="event.preventDefault(); document.getElementById('upload').click();" href="#"><i class="fas fa-lg fa-edit"></i></a>
                  <a onclick="event.preventDefault(); removeImage('upload', 'imageViewer', 'toggleRemoveImage');" href="#"><i class="fas fa-lg fa-trash"></i></a>
                </span>
              <?php else: ?>
                <span class="control control-box">
                  <a id="controlAdd" onclick="event.preventDefault(); document.getElementById('upload').click();" href="#"><i class="fas fa-lg fa-plus"></i></a>
                  <a id="controlRemove" onclick="event.preventDefault(); removeImage('upload', 'imageViewer', 'toggleRemoveImage');" href="#" class="hide" ><i class="fas fa-lg fa-trash"></i></a>
                </span>
              <?php endif; ?>
          </div>
          <input onchange="previewImage('upload', 'imageViewer', 'toggleRemoveImage');" style="display:none;" type="file" id="upload" name="upload" class="form-control" accept="image/*">
        <?php else: ?>
          <label>Image</label>
          <div class="box full-width-sm">
              <img src="<?php echo e(Arins\Facades\Filex::image($viewModel->data->image)); ?>" alt="">
          </div>
        <?php endif; ?>
      </div>

      <!-- input text -->
      <div class="form-group">
        <label>NIK</label>
        <input type="text" <?php echo e($disabled); ?> id="nik" name="nik" class="form-control" placeholder=""
        value="<?php echo e(($errors->any() ? old('nik') : $viewModel->data->nik )); ?>">
        <p class="text-red"><?php echo e($errors->first('nik')); ?></p>
      </div>

      <!-- input text -->
      <div class="form-group">
        <label>Nama</label>
        <input type="text" <?php echo e($disabled); ?> id="name" name="name" class="form-control" placeholder=""
        value="<?php echo e(( $errors->any() ? old('name') : $viewModel->data->name )); ?>">
        <p class="text-red"><?php echo e($errors->first('name')); ?></p>
      </div>

      <!-- text input:text -->
      <div class="form-group">
        <label>Departemen</label>
        <?php if($fieldEnabled == true): ?>
          <select name="subdept_id" class="form-control">
                <?php $__currentLoopData = $subdept; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($errors->any()): ?>
                    <?php echo e(($item->id == old('subdept_id') ? $selected = 'selected' : $selected = '')); ?>

                  <?php else: ?>
                    <?php echo e(( $item->id == $viewModel->data->subdept_id ) ? $selected = 'selected' : $selected = ''); ?>

                  <?php endif; ?>
                  <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
          <input type="hidden" name="job_id" value="<?php echo e($viewModel->data->subdept_id); ?>" readonly>
          <div class="form-group">
              <input disabled type="text" value="<?php echo e($viewModel->data->subdept->name); ?>" class="form-control">
          </div>
        <?php endif; ?>
        <p class="text-red"><?php echo e($errors->first('job_id')); ?></p>

      </div>

      <!-- text input:text -->
      <div class="form-group">
        <label>Jabatan</label>
        <?php if($fieldEnabled == true): ?>
          <select name="job_id" class="form-control">
                <?php $__currentLoopData = $job; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($errors->any()): ?>
                    <?php echo e(($item->id == old('job_id') ? $selected = 'selected' : $selected = '')); ?>

                  <?php else: ?>
                    <?php echo e(( $item->id == $viewModel->data->job_id ) ? $selected = 'selected' : $selected = ''); ?>

                  <?php endif; ?>
                  <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
          <input type="hidden" name="job_id" value="<?php echo e($viewModel->data->job_id); ?>" readonly>
          <div class="form-group">
              <input disabled type="text" value="<?php echo e($viewModel->data->job->name); ?>" class="form-control">
          </div>
        <?php endif; ?>
        <p class="text-red"><?php echo e($errors->first('job_id')); ?></p>

      </div>
      
      <hr>

      <!-- input text -->
      <div class="form-group">
        <label>Keterangan</label>
        <input type="text" <?php echo e($disabled); ?> id="add_info1" name="add_info1" class="form-control" placeholder=""
        value="<?php echo e(( $errors->any() ? old('add_info1') : $viewModel->data->add_info1 )); ?>">
        <p class="text-red"><?php echo e($errors->first('add_info1')); ?></p>
      </div>


    </div>
</div>


<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/employee/data-field-items.blade.php ENDPATH**/ ?>