<?php (($fieldEnabled == true ? $disabled='' : $disabled='disabled')); ?>
<div class="card" style="margin-bottom: 20px; width: 50%;
margin-left: auto; margin-right:auto;">
    <div class="card-body">

      <!-- text input:file -->
      <div class="form-group">
        <input type="hidden" id="image" name="image" value="<?php echo e($viewModel->data->image); ?>" placeholder="image">
        <input type="hidden" id="toggleRemoveImage" name="toggleRemoveImage" value="false">
        <input type="hidden" id="imageTemp" name="imageTemp" value="<?php echo e(session('imageTemp')); ?>" placeholder="imageTemp">

        <?php if($fieldEnabled == true): ?>
          <label>Image</label>
          <div class="box full-width-sm">
              <?php if(session('imageTemp')): ?>
                <img id="imageViewer" src="<?php echo e(Arins\Facades\Filex::image(session('imageTemp'))); ?>" alt="">
              <?php else: ?>
                <img id="imageViewer" src="<?php echo e(Arins\Facades\Filex::image($viewModel->data->image)); ?>" alt="">
              <?php endif; ?>

              <?php if($viewModel->data->image): ?>
                <span class="control control-widebox">  
                  <a onclick="event.preventDefault(); document.getElementById('upload').click();" href="#"><i class="fas fa-lg fa-edit"></i></a>
                  <a onclick="event.preventDefault(); removeImage('upload', 'imageViewer', 'toggleRemoveImage');" href="#"><i class="fas fa-lg fa-trash"></i></a>
                </span>
              <?php else: ?>
                <span class="control control-box">
                  <a id="controlAdd" onclick="event.preventDefault(); document.getElementById('upload').click();" href="#"><i class="fas fa-lg fa-plus"></i></a>
                  <a id="controlRemove" onclick="event.preventDefault(); removeImage('upload', 'imageViewer', 'toggleRemoveImage');" href="#" class="hide" ><i class="fas fa-lg fa-trash"></i></a>
                </span>
              <?php endif; ?>
          </div>
          <input onchange="previewImage('upload', 'imageViewer', 'toggleRemoveImage');" style="display:none;" type="file" id="upload" name="upload" class="form-control" accept="image/*">
        <?php else: ?>
          <label>Image</label>
          <div class="box full-width-sm">
              <img src="<?php echo e(Arins\Facades\Filex::image($viewModel->data->image)); ?>" alt="">
          </div>
        <?php endif; ?>
      </div>

      <div class="form-group">
        <label>Category</label>
        <?php if($fieldEnabled == true): ?>
          <select name="tasktype_id" class="form-control">
                <?php $__currentLoopData = $tasktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($errors->any()): ?>
                    <?php echo e(($item->id == old('tasktype_id') ? $selected = 'selected' : $selected = '')); ?>

                  <?php else: ?>
                    <?php echo e(( $item->id == $viewModel->data->tasktype_id ) ? $selected = 'selected' : $selected = ''); ?>

                  <?php endif; ?>
                  <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
          <input type="hidden" name="tasktype_id" value="<?php echo e($viewModel->data->tasktype_id); ?>" readonly>
          <div class="form-group">
              <input disabled type="text" value="<?php echo e($viewModel->data->tasktype->name); ?>" class="form-control">
          </div>
        <?php endif; ?>
        <p class="text-red"><?php echo e($errors->first('tasktype_id')); ?></p>

      </div>
      
      <div class="form-group">
        <label>Sub Kategori</label>
        <?php if($fieldEnabled == true): ?>
          <select name="tasksubtype1_id" class="form-control">
                <?php $__currentLoopData = $tasksubtype1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <?php if($errors->any()): ?>
                    <?php echo e(($item->id == old('tasksubtype1_id') ? $selected = 'selected' : $selected = '')); ?>

                  <?php else: ?>
                    <?php echo e(( $item->id == $viewModel->data->tasksubtype1_id ) ? $selected = 'selected' : $selected = ''); ?>

                  <?php endif; ?>
                  <option <?php echo e($selected); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        <?php else: ?>
          <input type="hidden" name="tasksubtype1_id" value="<?php echo e($viewModel->data->tasksubtype1_id); ?>" readonly>
          <div class="form-group">
              <input disabled type="text" value="<?php echo e($viewModel->data->tasksubtype1->name); ?>" class="form-control">
          </div>
        <?php endif; ?>
        <p class="text-red"><?php echo e($errors->first('tasksubtype1_id')); ?></p>

      </div>

<hr>
      
      <!-- text input -->
      <div class="form-group">
        <label>Nama</label>
        <input <?php echo e($disabled); ?> type="text" id="name" name="name" class="form-control" value="<?php echo e(( $errors->any() ? old('name') : $viewModel->data->name )); ?>">
        <p class="text-red"><?php echo e($errors->first('name')); ?></p>
      </div>

      <!-- textarea -->
      <div class="form-group">
        <label>Deskripsi</label>
        <textarea <?php echo e($disabled); ?> id="description" name="description" class="form-control" rows="3" placeholder=""><?php echo e(( $errors->any() ? old('description') : $viewModel->data->description )); ?></textarea>
        <p class="text-red"><?php echo e($errors->first('description')); ?></p>
      </div>

    </div>
</div>


<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/masteritem/data-field-items.blade.php ENDPATH**/ ?>