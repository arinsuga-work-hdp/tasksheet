<h5>Filter Data</h5>
<hr class="mb-2">
<form role="form">
    <input type="hidden" id="filter0" name="filter0">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter1" name="filter1" class="form-control float-right" placeholder="Status" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter2" name="filter2" class="form-control float-right" placeholder="mulai" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter3" name="filter3" class="form-control float-right" placeholder="selesai" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter4" name="filter4" class="form-control float-right" placeholder="Jenis Project" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter5" name="filter5" class="form-control float-right" placeholder="Project" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter6" name="filter6" class="form-control float-right" placeholder="Subject" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter7" name="filter7" class="form-control float-right" placeholder="Deskripsi" style="margin-left: 5px;">
            </div>
        </div>
    </div>

</form>
