<a href="{{ config('a1.onlineshop.tokopedia.link') }}" target="_blank">
    <img class="logo-brand" src="{{ asset( config('a1.onlineshop.tokopedia.logo') ) }}" alt="">
</a>
