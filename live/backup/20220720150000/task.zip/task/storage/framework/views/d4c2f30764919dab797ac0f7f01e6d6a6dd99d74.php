

<?php $__env->startSection('content_title', 'Master Item List'); ?>

<?php $__env->startSection('toolbar'); ?>

<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('masteritem.create')); ?>">
        <i class="fas fa-lg fa-plus"></i>
    </a>
</li>

<li class="nav-item">
    <a class="nav-link" data-widget="control-sidebar" href="#" >
        <i class="fas fa-lg fa-filter"></i>
    </a>
</li>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('control_sidebar'); ?>
    <div class="control-sidebar-content">
        <?php echo $__env->make('bo.masteritem.data-list-filters', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

        <div style="margin-top: 10px;">
            <?php echo $__env->make('bo.masteritem.data-list-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script src="<?php echo e(asset('js/CustomForIndex.js')); ?>" defer></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/masteritem/index.blade.php ENDPATH**/ ?>