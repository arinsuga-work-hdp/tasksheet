<h5>Filter Data</h5>
<hr class="mb-2">
<form role="form">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter0" name="filter0" class="form-control float-right" placeholder="Requester" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter1" name="filter1" class="form-control float-right" placeholder="Department" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter2" name="filter2" class="form-control float-right" placeholder="Category" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter3" name="filter3" class="form-control float-right" placeholder="Subcategory" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter4" name="filter4" class="form-control float-right" placeholder="Subject" style="margin-left: 5px;">
            </div>
        </div>
    </div>

    <input type="hidden" id="filter5" name="5">
    <input type="hidden" id="filter6" name="6">
    <input type="hidden" id="filter7" name="7">
    <input type="hidden" id="filter8" name="8">
    <input type="hidden" id="filter9" name="9">

    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter10" name="filter10" class="form-control float-right" placeholder="Start Time" style="margin-left: 5px;">
            </div>
        </div>
    </div>
    <div class="mt-2 row">
        <div class="col-sm-12">
            <div class="form-group">
            <input type="text" id="filter11" name="filter11" class="form-control float-right" placeholder="Completed Time" style="margin-left: 5px;">
            </div>
        </div>
    </div>
</form>
