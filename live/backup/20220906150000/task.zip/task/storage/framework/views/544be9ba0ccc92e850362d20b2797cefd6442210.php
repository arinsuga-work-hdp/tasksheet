

<?php $__env->startSection('content_title', 'Maintenance Info'); ?>

<?php $__env->startSection('toolbar'); ?>

<!-- button back -->
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.index')); ?>">
        <i class="fas fa-lg fa-arrow-left"></i>
    </a>
</li>

<!-- <li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.close', ['maintenance' => $viewModel->data->id])); ?>">
        <span style="font-weight: bold;">status = <?php echo e($viewModel->data->activitystatus_id); ?></span>
    </a>
</li> -->

<?php if($viewModel->data->activitystatus_id == 1): ?>
<!-- button close -->
<li class="nav-item">

    <!-- <a class="nav-link" href="<?php echo e(route('maintenance.close', ['maintenance' => $viewModel->data->id])); ?>">
        <span style="font-weight: bold;">Close</span>
    </a> -->

    <a  onclick="event.preventDefault();"
        data-toggle="modal" data-target="#modal-close"
        class="nav-link" href="#"
    ><span style="font-weight: bold;">Close</span></a>

    
</li>
<!-- button pending -->
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.pending', ['maintenance' => $viewModel->data->id])); ?>">
        <span style="font-weight: bold;">Pending</span>
    </a>
</li>
<!-- button cancel -->
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.cancel', ['maintenance' => $viewModel->data->id])); ?>">
        <span style="font-weight: bold;">Cancel</span>
    </a>
</li>

<!-- button edit -->
<li class="nav-item">
    <a class="nav-link" href="<?php echo e(route('maintenance.edit', ['maintenance' => $viewModel->data->id])); ?>">
        <i class="fas fa-lg fa-edit"></i>
    </a>
</li>
<?php endif; ?>


<!-- button delete -->
<li class="nav-item">

    <!-- <a onclick="event.preventDefault(); document.getElementById('frmData').submit();"
       class="nav-link" href="#">
        <i class="fas fa-lg fa-trash"></i>
    </a> -->

    <a  onclick="event.preventDefault();"
        data-toggle="modal" data-target="#modal-delete"
        class="nav-link" href="#"
    >
        <i class="fas fa-lg fa-trash"></i>
    </a>


    <form id="frmData" role="form" id="frmData" method="POST" action="<?php echo e(route('maintenance.destroy', ['maintenance' => $viewModel->data->id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
    </form>
</li>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('bo.maintenance.data-field-items', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

    <!-- Styles -->
    <!-- <link href="<?php echo e(asset('css/CustomForShow.css')); ?>" rel="stylesheet"> -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <!-- javascript -->
    <!-- <script src="<?php echo e(asset('js/CustomForShow.js')); ?>" defer></script> -->

    <script>
        
        var modalClose = $("#modalClose");
        var modalCloseResolution = $("#modalCloseResolution");

        function deleteActivity() {

            modalClose.click();
            event.preventDefault();
            document.getElementById('frmData').submit();

        } //end method

        function closeActivity() {

            modalCloseResolution.click();
            event.preventDefault();
            document.getElementById('frmDataClose').submit();

        } //end method

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('bo.maintenance.modal-delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
<?php echo $__env->make('bo.maintenance.modal-close', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/maintenance/show.blade.php ENDPATH**/ ?>