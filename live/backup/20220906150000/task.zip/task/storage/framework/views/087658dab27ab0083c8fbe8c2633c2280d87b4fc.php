

<?php $__env->startSection('content'); ?>

<div class="container">
    
<div class="container">
    <div class="box" style="border: none;">
        <img style="width: 90%;" src="<?php echo e(asset('img/'.config('a1.uiux.logo_landscape'))); ?>" alt="">
    </div>
</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appbo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/home/index.blade.php ENDPATH**/ ?>