<table id="filter" style="width: 100%;" class="table table-hover-pointer table-head-fixed text-nowrap">
    <thead>
        <tr>
            <th style="width: 5%;"></th>
            <th style="width: 5%;">Status</th>
            <th style="width: 5%;">Mulai</th>
            <th style="width: 5%;">Selesai</th>
            <th style="width: 10%;">Category</th>
            <th style="width: 15%;">Subject</th>
            <th style="width: 55%;">Deskripsi</th>
        </tr>
    </thead>
    <tbody>

        <?php $__currentLoopData = $viewModel->data->datalist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr onclick="window.location.assign('<?php echo e(route('support.show', ['support' => $item->id])); ?>');">
                <td>
                    <div class="image-table-cell">
                        <img src="<?php echo e(Arins\Facades\Filex::image($item->image)); ?>" alt="<?php echo e($item->name); ?>">
                    </div>
                </td>
                <td><?php echo e($item->activitystatus->name); ?></td>
                <td>
                    <div class="text-center"><?php echo e(\Arins\Facades\Formater::datetime($item->startdt)); ?></div>
                </td>
                <td>
                    <div class="text-center"><?php echo e(\Arins\Facades\Formater::datetime($item->enddt)); ?></div>
                </td>
                <td>
                    <div class="truncate-multiline"><?php echo nl2br(e($item->tasktype->name)); ?></div>
                </td>
                <td>
                    <div class="truncate-multiline"><?php echo nl2br(e($item->subject)); ?></div>
                </td>
                <td>
                    <div class="truncate-multiline"><?php echo nl2br(e($item->description)); ?></div>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
</table>
<?php /**PATH /home/u1045649/hadiprana-design-2020/public/task/resources/views/bo/support/index-custom-datalist.blade.php ENDPATH**/ ?>